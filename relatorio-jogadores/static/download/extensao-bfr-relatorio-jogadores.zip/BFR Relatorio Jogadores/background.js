// BFR Relatório Jogadores — ponte entre o card "Relatório do Atleta" (hub :5555) e o Wyscout já
// logado neste Chrome. Separada da extensão BFR Wyscout (Posições e Sistemas / IPOB) por decisão
// do Henrique (02/10/2026). Usa a aba do Wyscout para fazer as mesmas consultas que as telas do
// Wyscout fazem. Não guarda senha nem dados.
const VERSAO = '1.2.0';
const WY = 'https://wyscout.hudl.com/app/';
const API = 'https://searchapi.wyscout.com/api/v1';
const dorme = (ms) => new Promise((r) => setTimeout(r, ms));

/* ── funções injetadas na página do Wyscout (rodam lá, com o login de quem usa) ── */
function pgLogado() { return !!(window.uidirectives && window.uidirectives.access_key); }
async function pgGet(url) {
  const tok = window.uidirectives && window.uidirectives.access_key;
  if (!tok) return { __erro: 'login' };
  const u = url + (url.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok);
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(u);
      if (r.ok) return await r.json();
      if (r.status === 401 || r.status === 403) return { __erro: 'login' };
    } catch (e) { /* tenta de novo */ }
    await new Promise((ok) => setTimeout(ok, 800 * (t + 1)));
  }
  return { __erro: 'rede' };
}
async function pgBusca(nome) {
  // busca livre: tenta como foi digitado; sem resultado, tenta sem acento e em minúsculas
  const sem = (s) => s.normalize('NFKD').replace(/[\u0300-\u036f]/g, '');
  const tentativas = [...new Set([nome.trim(), sem(nome.trim()), sem(nome.trim()).toLowerCase()])].filter(Boolean);
  for (const q of tentativas) {
    let r, t;
    try {
      const body = 'query=' + encodeURIComponent(JSON.stringify({ obj: 'search', act: 'player', params: { search: q }, navi: { component: 'global_search_player' } }));
      r = await fetch('/app/aengine-service.php', { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' } });
      t = await r.text();
    } catch (e) { return { __erro: 'busca' }; }
    let j = null; try { j = JSON.parse(t); } catch (e) {}
    // deslogado: o Wyscout responde 404 "Not found." (ou manda para a tela de login da Hudl)
    if (!j) return { __erro: (r.status === 404 || r.status === 401 || r.status === 403 || /log ?in/i.test(t)) ? 'login' : 'busca' };
    const lista = (j.list || []).filter((x) => x.obj === 'player').map((x) => ({ id: x.objId, nome: (x.title || '').trim(), subtitulo: (x.subtitle || '').trim(), foto: x.img_url || '' }));
    if (lista.length) return lista;
  }
  return [];
}

/* ── aba do Wyscout ── */
async function roda(tabId, func, args = []) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args });
  return r ? r.result : undefined;
}
async function abaWyscout(avisa) {
  let [tab] = await chrome.tabs.query({ url: 'https://wyscout.hudl.com/*' });
  let criada = false;
  if (!tab) { avisa('Abrindo o Wyscout...'); tab = await chrome.tabs.create({ url: WY, active: false }); criada = true; }
  const t0 = Date.now();
  while (Date.now() - t0 < 40000) {
    try { if (await roda(tab.id, pgLogado)) return tab; } catch (e) { /* página ainda carregando */ }
    await dorme(1000);
    if (!criada && Date.now() - t0 > 6000) { try { await chrome.tabs.update(tab.id, { url: WY }); } catch (e) {} criada = true; }
  }
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
  const err = new Error('Faça o login no Wyscout na aba que abriu e tente de novo.'); err.code = 'login'; throw err;
}
function checa(r) {
  if (r && r.__erro === 'login') { const e = new Error('O Wyscout pediu login. Entre no Wyscout e tente de novo.'); e.code = 'login'; throw e; }
  if (!r || r.__erro) throw new Error('O Wyscout não respondeu. Tente de novo.');
  return r;
}
// A aba pode estar aberta há horas: a busca (cookie) funciona, mas o token da página venceu e a
// API recusa. Nesse caso recarrega a aba (token novo) e tenta uma vez de novo.
async function api(tabId, url, avisa) {
  let r = await roda(tabId, pgGet, [url]);
  if (r && r.__erro === 'login') {
    avisa('Sessão antiga na aba do Wyscout. Recarregando a aba...');
    await chrome.tabs.update(tabId, { url: WY });
    await dorme(1500);
    const t0 = Date.now();
    while (Date.now() - t0 < 40000) {
      try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete' && await roda(tabId, pgLogado)) break; } catch (e) {}
      await dorme(1000);
    }
    r = await roda(tabId, pgGet, [url]);
  }
  return checa(r);
}
const qs = (o) => Object.entries(o).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');

/* ── Transfermarkt e ogol (1.1.0, 02/10): a página do relatório lê as fontes no navegador (fontes.js) e a
   extensão só busca — SÓ estes sites. Imagem volta como data:URL. ── */
const HOSTS_FONTES = ['www.transfermarkt.com.br', 'www.transfermarkt.pt', 'www.transfermarkt.com', 'tmapi.transfermarkt.technology', 'img.a.transfermarkt.technology',
  'tmssl.akamaized.net', 'www.ogol.com.br', 'cdn-img.staticzz.com'];
async function baixar(url, como) {
  let u; try { u = new URL(url); } catch (e) { throw new Error('endereço inválido'); }
  if (u.protocol !== 'https:' || !HOSTS_FONTES.includes(u.hostname)) throw new Error('site fora da lista das fontes');
  const r = await fetch(u.href, { headers: { 'Accept': como === 'json' ? 'application/json' : '*/*', 'Accept-Language': 'pt-BR,pt;q=0.9' } });
  if (!r.ok) throw new Error(`${u.hostname} respondeu ${r.status}`);
  if (como !== 'bytes') return { texto: await r.text() };
  const b = new Uint8Array(await r.arrayBuffer());
  let bin = ''; for (let i = 0; i < b.length; i += 0x8000) bin += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return { dataurl: `data:${r.headers.get('content-type') || 'image/jpeg'};base64,` + btoa(bin) };
}

/* ── conversa com o card ── */
chrome.runtime.onConnectExternal.addListener((port) => {
  port.onMessage.addListener(async (msg) => {
    const id = msg.id, manda = (o) => { try { port.postMessage({ id, ...o }); } catch (e) {} };
    const avisa = (texto) => manda({ log: texto });
    try {
      if (msg.tipo === 'ping') return manda({ ok: true, versao: VERSAO });
      if (msg.tipo === 'baixar') return manda({ ok: true, ...(await baixar(String(msg.url || ''), msg.como)) });   // não precisa do Wyscout
      const tab = await abaWyscout(avisa);
      if (msg.tipo === 'buscar') {
        const r = await roda(tab.id, pgBusca, [String(msg.nome || '')]);
        if (r && r.__erro === 'login') { try { await chrome.tabs.update(tab.id, { url: WY, active: true }); } catch (e) {} }
        return manda({ ok: true, jogadores: checa(r) });
      }
      const pid = parseInt(msg.jogador_id, 10);
      if (msg.tipo === 'jogos') { // todos os jogos do jogador no período (posição e minutos)
        avisa('Baixando os jogos do jogador...');
        const raw = await api(tab.id, `${API}/match_stats/players/${pid}?` + qs({ lang: 'pt', score: 'winning,draw,losing', venue: 'home,away', from: msg.de || '2010-07-01', to: msg.ate || '', columns: 'name,positions,minutes_on_field' }), avisa);
        const jogos = (Array.isArray(raw) ? raw : []).map((x) => ({
          match_id: x.match.id, data: x.match.date, jogo: x.match.name, competicao: x.match.competition,
          flag: x.match.competitionFlag || '', temporada: x.match.seasonName,
          posicoes: (x.playerStats && x.playerStats.positions) || [], minutos: (x.playerStats && x.playerStats.minutes_on_field) || 0,
        }));
        return manda({ ok: true, jogos });
      }
      if (msg.tipo === 'heatmap') { // mapa de calor SÓ dos jogos pedidos (match_ids — é o que a tela do Wyscout usa;
        // os parâmetros from/to são ignorados pela API e devolvem sempre o mesmo mapa)
        const ids = (msg.match_ids || []).map((x) => parseInt(x, 10)).filter(Boolean);
        if (!ids.length) return manda({ ok: true, pontos: [] });
        const r = await api(tab.id, `${API}/match_stats/players/${pid}/heatmap?match_ids=${ids.join(',')}`, avisa);
        return manda({ ok: true, pontos: ((r && r.heatmap) || []).flat() });
      }
      manda({ erro: 'Pedido desconhecido.' });
    } catch (e) {
      manda({ erro: e.message || String(e), code: e.code || null });
    }
  });
});
chrome.runtime.onMessageExternal.addListener((msg, _s, responde) => { if (msg && msg.tipo === 'ping') responde({ ok: true, versao: VERSAO }); });
