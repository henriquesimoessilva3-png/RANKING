// BFR Relatório Jogadores — ponte entre o card "Relatório do Atleta" (hub :5555) e o Wyscout já
// logado neste Chrome. Separada da extensão BFR Wyscout (Posições e Sistemas / IPOB) por decisão
// do Henrique (02/10/2026). Usa a aba do Wyscout para fazer as mesmas consultas que as telas do
// Wyscout fazem. Não guarda senha nem dados.
const VERSAO = '1.5.1';
const WY = 'https://wyscout.hudl.com/app/';
const API = 'https://searchapi.wyscout.com/api/v1';
const dorme = (ms) => new Promise((r) => setTimeout(r, ms));

/* ── funções injetadas na página do Wyscout (rodam lá, com o login de quem usa) ── */
function pgLogado() { return !!(window.uidirectives && window.uidirectives.access_key); }
async function pgGet(url) {
  const tok = window.uidirectives && window.uidirectives.access_key;
  if (!tok) return { __erro: 'login' };
  const u = url + (url.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok);
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(u);
      if (r.ok) return await r.json();
      if (r.status === 401 || r.status === 403) return { __erro: 'login' };
    } catch (e) { /* tenta de novo */ }
    await new Promise((ok) => setTimeout(ok, 800 * (t + 1)));
  }
  return { __erro: 'rede' };
}
async function pgBusca(nome) {
  // busca livre: tenta como foi digitado; sem resultado, tenta sem acento e em minúsculas
  const sem = (s) => s.normalize('NFKD').replace(/[\u0300-\u036f]/g, '');
  const tentativas = [...new Set([nome.trim(), sem(nome.trim()), sem(nome.trim()).toLowerCase()])].filter(Boolean);
  for (const q of tentativas) {
    let r, t;
    try {
      const body = 'query=' + encodeURIComponent(JSON.stringify({ obj: 'search', act: 'player', params: { search: q }, navi: { component: 'global_search_player' } }));
      r = await fetch('/app/aengine-service.php', { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' } });
      t = await r.text();
    } catch (e) { return { __erro: 'busca' }; }
    let j = null; try { j = JSON.parse(t); } catch (e) {}
    // deslogado: o Wyscout responde 404 "Not found." (ou manda para a tela de login da Hudl)
    if (!j) return { __erro: (r.status === 404 || r.status === 401 || r.status === 403 || /log ?in/i.test(t)) ? 'login' : 'busca' };
    const lista = (j.list || []).filter((x) => x.obj === 'player').map((x) => ({ id: x.objId, nome: (x.title || '').trim(), subtitulo: (x.subtitle || '').trim(), foto: x.img_url || '' }));
    if (lista.length) return lista;
  }
  return [];
}

/* ── aba do Wyscout ── */
async function roda(tabId, func, args = []) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args });
  return r ? r.result : undefined;
}
async function abaWyscout(avisa) {
  let [tab] = await chrome.tabs.query({ url: 'https://wyscout.hudl.com/*' });
  let criada = false;
  if (!tab) { avisa('Abrindo o Wyscout...'); tab = await chrome.tabs.create({ url: WY, active: false }); criada = true; }
  const t0 = Date.now();
  while (Date.now() - t0 < 40000) {
    try { if (await roda(tab.id, pgLogado)) return tab; } catch (e) { /* página ainda carregando */ }
    await dorme(1000);
    if (!criada && Date.now() - t0 > 6000) { try { await chrome.tabs.update(tab.id, { url: WY }); } catch (e) {} criada = true; }
  }
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
  const err = new Error('Faça o login no Wyscout na aba que abriu e tente de novo.'); err.code = 'login'; throw err;
}
function checa(r) {
  if (r && r.__erro === 'login') { const e = new Error('O Wyscout pediu login. Entre no Wyscout e tente de novo.'); e.code = 'login'; throw e; }
  if (!r || r.__erro) throw new Error('O Wyscout não respondeu. Tente de novo.');
  return r;
}
// A aba pode estar aberta há horas: a busca (cookie) funciona, mas o token da página venceu e a
// API recusa. Nesse caso recarrega a aba (token novo) e tenta uma vez de novo.
async function api(tabId, url, avisa) {
  let r = await roda(tabId, pgGet, [url]);
  if (r && r.__erro === 'login') {
    avisa('Sessão antiga na aba do Wyscout. Recarregando a aba...');
    await chrome.tabs.update(tabId, { url: WY });
    await dorme(1500);
    const t0 = Date.now();
    while (Date.now() - t0 < 40000) {
      try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete' && await roda(tabId, pgLogado)) break; } catch (e) {}
      await dorme(1000);
    }
    r = await roda(tabId, pgGet, [url]);
  }
  return checa(r);
}
const qs = (o) => Object.entries(o).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');

/* ── Transfermarkt e ogol (1.1.0, 02/10): a página do relatório lê as fontes no navegador (fontes.js) e a
   extensão só busca — SÓ estes sites. Imagem volta como data:URL. ── */
const HOSTS_FONTES = ['www.transfermarkt.com.br', 'www.transfermarkt.pt', 'www.transfermarkt.com', 'tmapi.transfermarkt.technology', 'img.a.transfermarkt.technology',
  'tmssl.akamaized.net', 'www.ogol.com.br', 'cdn-img.staticzz.com',
  'www.sofascore.com',   // 1.4.0 (15/10): nota SofaScore dos Indicados no Scout System
  'img.sofascore.com', 'sortitoutsidospaces.b-cdn.net', 'transferroom.blob.core.windows.net',
  'www.zerozero.pt'];   // 1.5.1 (19/10): reserva do ogol (mesmo site, mesmos links)   // 1.5.0 (19/10): fotos e escudos da Lista de Observação
async function baixarDireto(url, como) {
  let u; try { u = new URL(url); } catch (e) { throw new Error('endereço inválido'); }
  if (u.protocol !== 'https:' || !HOSTS_FONTES.includes(u.hostname)) throw new Error('site fora da lista das fontes');
  const r = await fetch(u.href, { credentials: 'include', headers: { 'Accept': como === 'json' ? 'application/json' : '*/*', 'Accept-Language': 'pt-BR,pt;q=0.9' } });
  if (!r.ok) throw new Error(`${u.hostname} respondeu ${r.status}`);
  if (como !== 'bytes') return { texto: await r.text() };
  const b = new Uint8Array(await r.arrayBuffer());
  let bin = ''; for (let i = 0; i < b.length; i += 0x8000) bin += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return { dataurl: `data:${r.headers.get('content-type') || 'image/jpeg'};base64,` + btoa(bin) };
}

/* 1.5.1 (19/10/2026): o ogol bloqueia (403) o pedido feito "por fora" em algumas internets — caso do Pedro. Aí o pedido é
   refeito de dentro de uma aba do próprio site (como uma visita normal; se aparecer a verificação "não sou robô", a aba fica
   na frente para a pessoa clicar) e, se ainda falhar, no zerozero.pt — o mesmo site, com os mesmos links. */
const OGOLS = ['www.ogol.com.br', 'www.zerozero.pt'];
function pgSemDesafio() { return !!document.body && !/just a moment|um momento|attention required|verify you are human|access denied/i.test(document.title + ' ' + (document.body.innerText || '').slice(0, 300)); }
async function pgBaixarAqui(url, como) {
  try {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) return { __erro: r.status };
    if (como !== 'bytes') return { texto: await r.text() };
    const b = await r.blob();
    return await new Promise((ok) => { const f = new FileReader(); f.onload = () => ok({ dataurl: f.result }); f.onerror = () => ok({ __erro: 'leitura' }); f.readAsDataURL(b); });
  } catch (e) { return { __erro: 'rede' }; }
}
async function baixarNaAba(url, como, avisa) {
  const u = new URL(url), nome = u.hostname.includes('zerozero') ? 'zerozero' : 'ogol';
  let [tab] = await chrome.tabs.query({ url: `https://${u.hostname}/*` });
  if (!tab) { avisa(`Abrindo o ${nome}...`); tab = await chrome.tabs.create({ url: `https://${u.hostname}/`, active: false }); }
  const t0 = Date.now(); let naFrente = false, ok = false;
  while (Date.now() - t0 < 120000) {
    try { const t = await chrome.tabs.get(tab.id); if (t.status === 'complete' && await roda(tab.id, pgSemDesafio)) { ok = true; break; } } catch (e) { /* carregando */ }
    if (!naFrente && Date.now() - t0 > 4000) {   // verificação do Cloudflare: só a pessoa pode clicar
      naFrente = true; avisa(`O ${nome} pediu a verificação "Confirme que é humano": clique nela na aba que abriu.`);
      try { await chrome.tabs.update(tab.id, { active: true }); await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
    }
    await dorme(1000);
  }
  if (!ok) throw new Error(`a verificação do ${nome} não foi feita`);
  const r = await roda(tab.id, pgBaixarAqui, [u.href, como]);
  if (!r || r.__erro) throw new Error(`${u.hostname} respondeu ${r ? r.__erro : 'nada'}`);
  return r;
}
async function baixar(url, como, avisa = () => {}) {
  try { return await baixarDireto(url, como); }
  catch (e) {
    let u; try { u = new URL(url); } catch (e2) { throw e; }
    if (!OGOLS.includes(u.hostname) || !/40[0-9]|429|5\d\d/.test(e.message)) throw e;
    const outro = new URL(u.href); outro.hostname = u.hostname === OGOLS[0] ? OGOLS[1] : OGOLS[0];
    const tentativas = [() => baixarNaAba(u.href, como, avisa), () => baixarDireto(outro.href, como), () => baixarNaAba(outro.href, como, avisa)];
    let ultimo = e;
    for (const t of tentativas) { try { return await t(); } catch (e3) { ultimo = e3; } }
    throw new Error(`o ogol bloqueou o pedido (${e.message}); tentei pela aba do site e pelo zerozero.pt e não deu (${ultimo.message}). Abra www.ogol.com.br neste Chrome, passe pela verificação se aparecer, e tente de novo.`);
  }
}

/* ── 1.5.0 (19/10/2026): Lista de Observação no Scout System ──
   TransferRoom Scout (dados do jogador e as listas do Squad View) e sortitoutsi (foto recortada).
   Os dois rodam numa aba do próprio site, com o login de quem usa — igual ao Wyscout acima. */
const TR = 'https://scout.transferroom.com/squad-view';
const SORTI = 'https://sortitoutsi.net/graphics/submissions/1/search';
async function abaDoSite(padrao, url, pronta, nome, avisa) {
  let [tab] = await chrome.tabs.query({ url: padrao });
  let criada = false;
  if (!tab) { avisa(`Abrindo o ${nome}...`); tab = await chrome.tabs.create({ url, active: false }); criada = true; }
  const t0 = Date.now();
  while (Date.now() - t0 < 45000) {
    try { const t = await chrome.tabs.get(tab.id); if (t.status === 'complete' && await roda(tab.id, pronta)) return tab; } catch (e) { /* carregando */ }
    await dorme(1000);
    if (!criada && Date.now() - t0 > 8000) { try { await chrome.tabs.update(tab.id, { url }); } catch (e) {} criada = true; }
  }
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
  const err = new Error(`Faça o login no ${nome} na aba que abriu e tente de novo.`); err.code = 'login'; throw err;
}
function pgTrPronto() { return !!localStorage.getItem('DS'); }
// listas do Squad View, enxutas: lista -> [{caixa (código do TR), ordem, jogador}]
async function pgTrListas(nomes) {
  // (a função roda sozinha dentro da aba do TransferRoom: o pedido com o token fica aqui dentro)
  const pgTr = async (caminho, corpo) => {
    const tok = localStorage.getItem('DS'); if (!tok) return { __erro: 'login' };
    const op = { headers: { 'Accept': 'application/json', 'Authorization': 'Bearer ' + tok } };
    if (corpo) { op.method = 'POST'; op.headers['Content-Type'] = 'application/json'; op.body = JSON.stringify(corpo); }
    try {
      const r = await fetch('https://api.scout.transferroom.com/api/v1/' + caminho, op);
      if (r.status === 401 || r.status === 403) return { __erro: 'login' };
      if (!r.ok) return { __erro: 'rede', status: r.status };
      return await r.json();
    } catch (e) { return { __erro: 'rede' }; }
  };
  const j = await pgTr('ShadowSquad/InitialInfo'); if (!j || j.__erro) return j;
  const enx = (p) => ({ id: p.id, nome: p.shortName, nomeCompleto: [p.firstName, p.lastName].filter(Boolean).join(' '), idade: p.age, nasc: p.birthDate,
    altura: p.height, pe: p.foot, pos1: p.firstPosition && p.firstPosition.code, pos2: p.secondPosition && p.secondPosition.code,
    clube: p.currentSquad && { id: p.currentSquad.id, nome: p.currentSquad.name, curto: p.currentSquad.shortName, escudo: p.currentSquad.logoUrl },
    origem: p.parentSquad && { id: p.parentSquad.id, nome: p.parentSquad.name, curto: p.parentSquad.shortName, escudo: p.parentSquad.logoUrl },
    valor: p.xtv && p.xtv.marketValue, contrato: p.contractExpiry || null, nota: p.rating, potencial: p.potentialRating, foto: p.photoUrl });
  const out = {};
  for (const it of (j.squadItems || [])) for (const ss of (it.shadowSquads || [])) {
    const nm = String(ss.name || '').trim(); if (nomes && !nomes.some((n) => nm.toUpperCase().startsWith(n))) continue;
    out[nm] = (ss.positions || []).map((p) => ({ caixa: String(p.position && p.position.code || '').trim(),
      jogadores: (p.players || []).sort((a, b) => a.order - b.order).map((x) => enx(x.player)) }));
  }
  return out;
}
async function pgTrBusca(nome) {
  // (a função roda sozinha dentro da aba do TransferRoom: o pedido com o token fica aqui dentro)
  const pgTr = async (caminho, corpo) => {
    const tok = localStorage.getItem('DS'); if (!tok) return { __erro: 'login' };
    const op = { headers: { 'Accept': 'application/json', 'Authorization': 'Bearer ' + tok } };
    if (corpo) { op.method = 'POST'; op.headers['Content-Type'] = 'application/json'; op.body = JSON.stringify(corpo); }
    try {
      const r = await fetch('https://api.scout.transferroom.com/api/v1/' + caminho, op);
      if (r.status === 401 || r.status === 403) return { __erro: 'login' };
      if (!r.ok) return { __erro: 'rede', status: r.status };
      return await r.json();
    } catch (e) { return { __erro: 'rede' }; }
  };
  const j = await pgTr('Player/GetSuggestions', { keyword: nome }); if (!j || j.__erro) return j;
  return (j.players || []).map((p) => ({ id: p.id, nome: p.shortName, nomeCompleto: [p.firstName, p.lastName].filter(Boolean).join(' '), idade: p.age, nasc: p.birthDate,
    altura: p.height, pe: p.foot, pos1: p.firstPosition && p.firstPosition.code, pos2: p.secondPosition && p.secondPosition.code,
    clube: p.currentSquad && { id: p.currentSquad.id, nome: p.currentSquad.name, curto: p.currentSquad.shortName, escudo: p.currentSquad.logoUrl },
    origem: p.parentSquad && { id: p.parentSquad.id, nome: p.parentSquad.name, curto: p.parentSquad.shortName, escudo: p.parentSquad.logoUrl },
    valor: p.xtv && p.xtv.marketValue, contrato: p.contractExpiry || null, foto: p.photoUrl }));
}
// sortitoutsi: busca pelo nome e devolve cada candidato com a ficha do FM26 e a versão mais nova da foto recortada
function pgSortiPronto() { return !!(window.axios && document.querySelector('meta[name="csrf-token"]')); }
async function pgSortiBusca(nome, max, extras) {
  let lista;
  if (extras && extras.length) lista = extras.map((x) => ({ fm_id: x.fmid, slug: x.slug || 'x', name: x.nome }));
  else {
    try { lista = (await window.axios.post('/api/search-records', { search_term: nome })).data.data; } catch (e) { return { __erro: 'login' }; }
    lista = (lista || []).filter((x) => x.type_id === 'person' && x.classification_id === 'player');
    lista.sort((a, b) => (b.last_game_id || 0) - (a.last_game_id || 0));
  }
  const out = [];
  for (const x of lista.slice(0, max || 10)) {
    const c = { fmid: x.fm_id, nome: x.name };
    try {
      const h = await (await fetch(`/football-manager-2026/person/${x.fm_id}/${x.slug}`)).text();
      const doc = new DOMParser().parseFromString(h, 'text/html'); doc.querySelectorAll('style,script').forEach((e) => e.remove());
      const t = doc.body.innerText.replace(/\s+/g, ' ');
      const g = (re) => { const m = t.match(re); return m ? m[1].trim() : ''; };
      c.nasc = g(/DOB (\d{4}-\d{2}-\d{2})/); c.nac = g(/Nationality (.+?) (?:Second Nationality|Contracted|Club|Gender|Position)/);
      c.clube = g(/Contracted Club (.+?) Club Contract/) || g(/ Club (.+?) Contract Type/); c.emprestado = g(/On Loan (?:From|At) (.+?) (?:Loan|Contract)/);
      c.pos = g(/Position (.+?) Current Ability/);
    } catch (e) {}
    if (c.nasc) {
      try {
        const h2 = await (await fetch('/graphics/submissions/1/search?fmid=' + x.fm_id)).text();
        const m = [...h2.matchAll(/megapacks\/cutoutfaces\/originals\/([^/"']+)\/(\d+)\.png/g)].filter((y) => y[2] === String(x.fm_id));
        c.versao = m.length ? m[0][1] : null;
      } catch (e) {}
    }
    out.push(c);
    await new Promise((ok) => setTimeout(ok, 250));
  }
  return out;
}
// elenco do clube no FM26 (para nome comum, quando a busca não traz o jogador): procura o time e lê o JSON da página
async function pgSortiElenco(clube, nome) {
  let ts;
  try { ts = (await window.axios.post('/api/search-records', { search_term: clube })).data.data; } catch (e) { return { __erro: 'login' }; }
  const sem = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const times = (ts || []).filter((x) => x.type_id === 'team' && (x.last_game_id || 0) >= 17).slice(0, 3);
  const nt = sem(nome).split(' ');
  const out = [];
  for (const tm of times) {
    try {
      const h = await (await fetch(`/football-manager-2026/team/${tm.fm_id}/${tm.slug}`)).text();
      for (const m of h.matchAll(/\{"id":\d+,"game_id":\d+,"game_version_id":\d+,"fm_id":(\d+)[^{}]*?"slug":"([^"]*)","name":"([^"]*)","first_name":"([^"]*)","second_name":"([^"]*)"/g)) {
        let n = m[3], f = m[4], s = m[5]; try { n = JSON.parse('"' + n + '"'); f = JSON.parse('"' + f + '"'); s = JSON.parse('"' + s + '"'); } catch (e) {}
        const full = sem([n, f, s].join(' ')).split(' ');
        if (nt.every((t) => full.includes(t))) out.push({ fmid: +m[1], slug: m[2], nome: n, time: tm.name });
      }
    } catch (e) {}
  }
  return out;
}

/* ── conversa com o card ── */
chrome.runtime.onConnectExternal.addListener((port) => {
  port.onMessage.addListener(async (msg) => {
    const id = msg.id, manda = (o) => { try { port.postMessage({ id, ...o }); } catch (e) {} };
    const avisa = (texto) => manda({ log: texto });
    try {
      if (msg.tipo === 'ping') return manda({ ok: true, versao: VERSAO });
      if (msg.tipo === 'baixar') return manda({ ok: true, ...(await baixar(String(msg.url || ''), msg.como, avisa)) });   // não precisa do Wyscout
      // 1.5.0: Lista de Observação (Scout System) — não precisam do Wyscout
      if (msg.tipo === 'tr_listas' || msg.tipo === 'tr_busca') {
        const tab = await abaDoSite('https://scout.transferroom.com/*', TR, pgTrPronto, 'TransferRoom Scout', avisa);
        const r = msg.tipo === 'tr_listas' ? await roda(tab.id, pgTrListas, [msg.nomes || null]) : await roda(tab.id, pgTrBusca, [String(msg.nome || '')]);
        if (r && r.__erro === 'login') { try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {} return manda({ erro: 'O TransferRoom pediu login. Entre no TransferRoom Scout e tente de novo.', code: 'login' }); }
        if (!r || r.__erro) return manda({ erro: 'O TransferRoom não respondeu. Tente de novo.' });
        return manda({ ok: true, dados: r });
      }
      if (msg.tipo === 'sorti_busca' || msg.tipo === 'sorti_elenco') {
        const tab = await abaDoSite('https://sortitoutsi.net/*', SORTI, pgSortiPronto, 'sortitoutsi', avisa);
        const r = msg.tipo === 'sorti_busca' ? await roda(tab.id, pgSortiBusca, [String(msg.nome || ''), msg.max || 10, msg.extras || null])
          : await roda(tab.id, pgSortiElenco, [String(msg.clube || ''), String(msg.nome || '')]);
        if (r && r.__erro === 'login') { try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {} return manda({ erro: 'O sortitoutsi pediu login. Entre no sortitoutsi e tente de novo.', code: 'login' }); }
        if (!r || r.__erro) return manda({ erro: 'O sortitoutsi não respondeu. Tente de novo.' });
        return manda({ ok: true, dados: r });
      }
      const tab = await abaWyscout(avisa);
      if (msg.tipo === 'buscar') {
        const r = await roda(tab.id, pgBusca, [String(msg.nome || '')]);
        if (r && r.__erro === 'login') { try { await chrome.tabs.update(tab.id, { url: WY, active: true }); } catch (e) {} }
        return manda({ ok: true, jogadores: checa(r) });
      }
      const pid = parseInt(msg.jogador_id, 10);
      if (msg.tipo === 'jogos') { // todos os jogos do jogador no período (posição e minutos)
        avisa('Baixando os jogos do jogador...');
        const raw = await api(tab.id, `${API}/match_stats/players/${pid}?` + qs({ lang: 'pt', score: 'winning,draw,losing', venue: 'home,away', from: msg.de || '2010-07-01', to: msg.ate || '', columns: 'name,positions,minutes_on_field' }), avisa);
        const jogos = (Array.isArray(raw) ? raw : []).map((x) => ({
          match_id: x.match.id, data: x.match.date, jogo: x.match.name, competicao: x.match.competition,
          flag: x.match.competitionFlag || '', temporada: x.match.seasonName,
          time_a: x.match.teamAId, time_b: x.match.teamBId, nome_a: x.match.teamA, nome_b: x.match.teamB,   // 1.3.0: para achar o clube do jogador
          posicoes: (x.playerStats && x.playerStats.positions) || [], minutos: (x.playerStats && x.playerStats.minutes_on_field) || 0,
        }));
        return manda({ ok: true, jogos });
      }
      if (msg.tipo === 'equipe') { // 1.3.0 (Posições e Sistemas): todos os jogos do CLUBE no período — total de jogos e de minutos do time
        const tid = parseInt(msg.time_id, 10); if (!tid) return manda({ erro: 'time sem id' });
        avisa('Baixando os jogos da equipe...');
        const r = await api(tab.id, `${API}/team_stats/teams/${tid}/stats?` + qs({ lang: 'pt', score: 'winning,draw,losing', venue: 'home,away', from: msg.de || '', to: msg.ate || '', columns: 'name' }), avisa);
        const jogos = ((r && r.matches) || []).map((m) => ({ match_id: m.match.id, data: m.match.date, competicao: m.match.competition, flag: m.match.competitionFlag || '',
          temporada: m.match.seasonName, duracao: m.match.duration || 0, jogo: m.match.name }));
        return manda({ ok: true, jogos });
      }
      if (msg.tipo === 'heatmap') { // mapa de calor SÓ dos jogos pedidos (match_ids — é o que a tela do Wyscout usa;
        // os parâmetros from/to são ignorados pela API e devolvem sempre o mesmo mapa)
        const ids = (msg.match_ids || []).map((x) => parseInt(x, 10)).filter(Boolean);
        if (!ids.length) return manda({ ok: true, pontos: [] });
        const r = await api(tab.id, `${API}/match_stats/players/${pid}/heatmap?match_ids=${ids.join(',')}`, avisa);
        return manda({ ok: true, pontos: ((r && r.heatmap) || []).flat() });
      }
      manda({ erro: 'Pedido desconhecido.' });
    } catch (e) {
      manda({ erro: e.message || String(e), code: e.code || null });
    }
  });
});
chrome.runtime.onMessageExternal.addListener((msg, _s, responde) => { if (msg && msg.tipo === 'ping') responde({ ok: true, versao: VERSAO }); });
